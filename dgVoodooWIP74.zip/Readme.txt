dgVoodoo WIP only version
-------------------------

=========================
WIP71:
=========================

Changes compared to v2.6.x:

- Experimental D3D12 backend for DirectX modules (no Glide for the time being)
- Fixing/changing some things in the frontend / D3D11 backend

=========================
WIP73:
=========================

- D3D12 backend for Glide
- Adding D3D12 with feature level 11.0 as output API
- Removing support for d3dcompiler_43 (affects only Glide)
- Minor bugfixings when refactoring the code
- Some bugs fixed in DX D3D12 backend (but I didn't address most of the known problems yet)
- Some bugs related to swapchains are also fixed

=========================
WIP74:
=========================

- D3D12 missing stencil plane copy in blitting operations, fixed (DDraw)
- D3D12 optional true partial depth buffer copy in blittings (DDraw) (GPU support required)
- D3D12 optional stencil read/writeback for depth buffer CPU access for forced resolutions/MSAA (DDraw, Glide3 Napalm) (GPU support required)
- D3D12 Draw*Instanced called with wrong parameter(s), fixed (60 Seconds For Mr. Light)
- D3D12 shader data reflection bug in the code generator, fixed (Carrier Gaia Command Mission, Valkyria Chronicles)
- D3D12 some initial optimization for sm5.1 in the code generator
- D3D12 strip-cut optimization for more optimal batching of DrawIndexed calls (D3D, Glide3, Glide3 Napalm)
- D3D12 Glide wrong gamma ramp parameter passing, fixed (single threaded case, NFS2)
- D3D11 minor backend bug fixed (my own tests)
- Output API option 'Best available' didn't choose D3D11 FL10.0 when that was the only available hw feature level, fixed
- Fixing a D3D frontend crash (scene demo Resurrection)
- Fixing a memory alloc bug in x64 D3D9
- Glide/DX cooperation defect causing crash, fixed (NFS2 demo)
